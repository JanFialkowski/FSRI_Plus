#' helper function for splitting an index vector in equally large chunks for each core used
#'
#' @param def_index numeric/integer, vector to be split
#' @param ncores integer, number of cores used in the parallel computation
#'
#' @return
#' @export
#'
#' @examples
#' split_vec(1:13, 3)
split_vec <- function(def_index, ncores){
  def_ind_length <- length(def_index) # total number of default cascades to run
  split_length <- ceiling(def_ind_length/ncores)
  def_ind_splits <- as.list(numeric(ncores))

  def_ind_splits[1:(ncores-1)] <-  lapply(1:(ncores-1), function(i) def_index[(split_length*(i-1)+1):(split_length*i)])
  def_ind_splits[[ncores]] <-  def_index[(split_length*(ncores-1)+1):(def_ind_length)]

  def_ind_splits
}

#' splits the psi_mat, specifying the shock spreading scenarios, in a list of submatrices used in the parallel computation of the cascade.
#'
#' @param psi_mat n times m (sparse) matrix, where element ij takes values between 0 and 1 and specifies the the shock to firm i in scenario j
#' @param ncores integer, number of cores used in the parallel computation
#' @param load_balance logical, TRUE load balancing is used, FALSE load balancing is not used
#'
#' @return list with the psi_mat sub-matrices that are used for each core in the parallel computation.
#' @export
#'
#' @examples
split_mat <- function(psi_mat,
                      ncores,
                      load_balance = FALSE){
  # function that splits psi_mat into chunks according to the number of cores. If n_scen mod n_cors != 0, the first x cores get one scenario extra.
  # The part of the function that is called when there are more cores than scenarios is typically not called, it gives FALSE in the list, bc no scenarios are left.
  n_scenarios <- ncol(psi_mat)

  if (n_scenarios >= ncores){

    if(load_balance == FALSE){
      split_length <- rep(floor(n_scenarios / ncores), ncores)

      if (n_scenarios%%ncores != 0) {
        split_length[1:(n_scenarios%%ncores)] <- split_length[1:(n_scenarios%%ncores)]+1
      }

      splits <- c(0,cumsum(split_length))
      psi_mat_splits <- as.list(numeric(ncores))
      psi_mat_splits[1:ncores] <- lapply(1:ncores, function(i) psi_mat[,(splits[i]+1):(splits[i+1]), drop = FALSE])

    }else{
      n_chunks <- ncores * 100
      if(n_chunks > n_scenarios){
        n_chunks <- n_scenarios
      }
      split_length <- rep(floor(n_scenarios / n_chunks), n_chunks)

      if (n_scenarios%%n_chunks != 0) {
        split_length[1:(n_scenarios%%n_chunks)] <- split_length[1:(n_scenarios%%n_chunks)]+1
      }

      splits <- c(0,cumsum(split_length))
      psi_mat_splits <- as.list(numeric(n_chunks))
      psi_mat_splits[1:n_chunks] <- lapply(1:n_chunks, function(i) psi_mat[,(splits[i]+1):(splits[i+1]), drop = FALSE])

    }

  }else{
    cat('More cores than scenarios, some cores would be idle. Using only' ,n_scenarios,  '.')
    ncores <- n_scenarios
    psi_mat_splits <- lapply(1:n_scenarios, function(i) psi_mat[,i, drop=FALSE])

    # split_length <- rep(0, ncores)
    # split_length[1:n_scenarios] <- 1
    # splits <- c(0, cumsum(split_length))
    #
    # psi_mat_splits <- as.list(numeric(ncores))
    # psi_mat_splits[1:n_scenarios] <- lapply(1:n_scenarios, function(i) psi_mat[,(splits[i]+1):(splits[i+1])])
    # psi_mat_splits[(n_scenarios+1):ncores] <- FALSE     # IDK if false is the right thing to set a core idle, but we'll see when it throws an error. please fix this whoever works with this
  }

  return(psi_mat_splits)
}

#' Calculate, Lambda_d, the downstream shock propagation matrix
#'
#' @param W n times n (sparse) matrix, where element ij specifies the (monetary) amount firm i sold to firm j, n is the number of firms
#' @param p n vector, where element i can take one of m values that specifies the industry affiliation of firm i (or alternatively the product type firm i produces)
#' @param p_cons n vector, where element i can take one of m values that specifies the industry affiliation where industries are consecutive, i.e. 1:m
#' @param ess_mat_sec m times m matrix, where element kl can take values 0 = negligible, 1 = non-essential and 2 = essential, specifies the essentiality of inputs from sector k for the production of a firm in sector l
#' @param pi_abs n times m matrix, where element ik specifies the amount of inputs firm i uses from sector k
#' @param in_str n vector, where element i specifies the in-strength of firm i (i.e. sum of all purchases, or in-links)
#' @param n integer, the number of firms
#'
#' @return sparse n times n matrix, Lambda_d, where element ij specifies the fraction of production firm j loses if supplier i can not deliver any goods and services of type p_i to firm j anymore.
#' @export
#'
#' @examples
Lambda_d_calc_r <- function(W,
                            p,
                            p_cons,
                            ess_mat_sec,
                            pi_abs,
                            in_str,
                            n = n){


  # calculate for each firm the essentiality matrix according to its sector affiliation
  #ess_mat <- Matrix::t(ess_mat_sec[,p])

  # make an edgelist out of W
  W_el <- cbind(Matrix::which(W > 0, arr.ind = TRUE), W[Matrix::which(W>0)])

  # W_el <- summary(W) if W is sparse thats easier
  Lambda_d_vec <- numeric(dim(W_el)[1])


  # for(i in 1:dim(W_el)[1]){
  #
  #   Lambda_d_vec[i] <-
  #     if( ess_mat[ W_el[i,2], p[W_el[i,1]] ] > 0 ){
  #
  #       W_el[i, 3] / pi_abs[ W_el[i,2], p[W_el[i,1]] ]
  #
  #     }else{
  #       W_el[i, 3] / in_str[W_el[i,2]]
  #     }
  #
  # }

  #ess_link_vec <-  ess_mat[ cbind(W_el[,2], p[W_el[,1]] )]
  # note that here we use the row and column names of ess_mat_sec for subsetting thats why we do not use p_cons
  ess_link_vec <-  ess_mat_sec[ cbind(as.character(p[W_el[,1]]), as.character(p[W_el[,2]] ))]



  Lambda_d_vec <- (ess_link_vec == 2) * (W_el[, 3] / pi_abs[ cbind(W_el[,2], p_cons[W_el[,1]] ) ]) +
    (ess_link_vec == 1) * (W_el[, 3] / in_str[W_el[,2]])
  # for (ess_lin_vec == 0) the entry is 0


  Lambda_d <- Matrix::sparseMatrix(i = W_el[,1],
                           j = W_el[,2],
                           x = Lambda_d_vec,
                           dims = c(n, n))

  Lambda_d
}



# Lambda_d_calc_r_with_prep <- function(W = W,
#                                       p = p,
#                                       ess_mat_sec = ess_mat_sec,
#                                       pi_abs = pi_abs,
#                                       in_str = in_str,
#                                       mix_prodfun = mix_prodfun,
#                                       serv_supp = serv_supp,
#                                       prodfun_sets = prodfun_sets, # kill
#                                       serv_supplier_sets = serv_supplier_sets, #kill
#                                       pf_type = pf_type,
#                                       m = m,
#                                       n = n
# ){
#
#
#   if( length(ess_mat_sec) <= 1){ # if ess_mat is not supplied need calculate it from other inputs
#
#     ess_mat_sec <- Matrix(0, m, m)
#
#     prodfun_sets_sec <- sapply(1:m, function(x) unique(prodfun_sets[(p == x)]) ) # reconstruct for each sector if its service or physical
#     serv_supplier_sets_sec <- sapply(1:m, function(x) unique(serv_supplier_sets[(p == x)]) ) # reconstruct for each sector if its service or physical
#
#     if( (mix_prodfun == TRUE) & (serv_supp == TRUE)){ # mixing 2 scenario (GL)
#       ess_mat_sec[serv_supplier_sets_sec == 2, prodfun_sets_sec == 2] <- 2
#       ess_mat_sec[ess_mat_sec == 0] <- 1
#     }
#
#     if( (mix_prodfun == TRUE) & (serv_supp == FALSE)){ # mixing 1 scenario
#       ess_mat_sec[, prodfun_sets_sec == 2] <- 2
#       ess_mat_sec[ess_mat_sec == 0] <- 1
#     }
#
#     if( ((mix_prodfun == FALSE) & (serv_supp == FALSE)) & pf_type == "Leontief"){
#       ess_mat_sec[,] <- 2
#     }
#
#     if( ((mix_prodfun == FALSE) & (serv_supp == FALSE)) & pf_type == "Linear"){
#       ess_mat_sec[,] <- 1
#     }
#
#   }
#
#
  # Lambda_d <- Lambda_d_calc_r(W = W,
  #                             p = p,
  #                             p_cons = p_cons,
  #                             ess_mat_sec = ess_mat_sec,
  #                             pi_abs = pi_abs,
  #                             in_str = in_str,
  #                             n = n)
#
#   Lambda_d
#
# }



# # n x n matrix, W_ij, amount firm i delivers to firm j, of product p_i
# W
#
# # n vector, p_i is the industry sector affiliation of firm i
# p
#
# # n vector, sector membership for each firm to calculate market shares in sustainability/ replaceability calculation
# p_market = p
#
# # n vector, sector membership for each firm to calculate aggregated shocks on the sector level
# p_sec_impacts = p   # cross check with sec_aggr_weights and track_sector_impacts = TRUE
#
# # m times m matrix, (m number of sectors) for each column the respective rows determines if the supplying sector is essential (=2), non-essential (=1), non important (=0)
# ess_mat_sec = FALSE
#
# # n times k matrix, each column gives a firm weight vector e.g. out-strength, employee number etc. if FALSE outstrenght is used as in Quantifying paper
# h_weights = FALSE
#
# # n times (column)vector, gives the weight of a firm within its sector for aggregating shocks to sector levels
# sec_aggr_weights = FALSE
#
# # n times k sparse!!! matrix, each column gives a exogenous shock scenario for each firm, if FALSE Identity matrix is used, i.e. each firm is defaulted separately giving its ESRI
# psi_mat = FALSE
#
# # n vector, firm revenues from income statements, used to adjust Lambda_u matrix when out strength is smaller than revenue to avoid overestimating local customers importance
# revenue = FALSE
#
# # n vector, firm material costs from incomestatements, used to adjust Lambda_u matrix when instrength is smaller than revenue to avoid overestimating local suppliers importance
# costs = FALSE
#
# # logical/bool, if TRUE the h^d(T) and h^u(T) vectors are outputted for each scenario as a matrix h_dmat and h_umat, column corresponds to lost production after the initial shock in the respective psi_mat column
# track_h = TRUE
#
# # logical/bool, if TRUE the shocks each firm receives are aggregated to the sectors specified by p_sec_impacts
# track_sector_impacts = TRUE # TRUE FALSE if firm impacts are aggregated to sectors
#
# # logical/bool, if TRUE the number of steps until convergence is tracked for each scenario and ESRI at T-1 and T to calculate the relative change of ESRI in the last time step
# track_conv = TRUE
#
# # numeric, if ==1 the difference between max(h_t - h_tp1)>eps is used if !=1 the relative change in overall production losses (ESRI(T)/ESRI(T-1))>(1+eps) is used as convergence threshold
# conv_type = 1
#
# # numeric, convergence threshold for cascades, 0.01 and conv_type =1 corresponds to firms adjusting their production until shocks become smaller than 1 % of their sales/inputs
# eps = 10^-2
#
# # logical/bool, if TRUE the fast rcpp code implementation is used (only works if fastcascade package is installed)
# use_rcpp = TRUE
#
# # numeric, if >0 the number specifies the number of cores used in the parallel computations
# ncores = detectCores()-4   # leave 4 cores to the machine
#
# # string, names the run
# run_id = FALSE
#
# # logical/bool, if true load balancing is used in parallel computations
# load_balance = FALSE,
#
# prodfun_sets = FALSE # kill in the future
# serv_supplier_sets = FALSE # kill in the future
#
#' Compute the ESRI (economic systemic risk index) for given firms' failure, or GL based shock propagation for more general initial shock to a production network.
#'
#' @param W n times n (sparse) matrix, where element ij specifies the (monetary) amount firm i sold to firm j, n is the number of firms
#' @param p n vector, where element i can take one of m values that specifies the industry affiliation of firm i (or alternatively the product type firm i produces)
#' @param p_market n vector, gives the sector affiliation of firm i for the market share calculation in the replaceability factor sigma_i (see paper)
#' @param p_sec_impacts n vector, gives the sector affiliation of firm i for the aggregation of firm level shocks at time T to the sector level
#' @param ess_mat_sec m times m matrix, where element kl can take values 0 = negligible, 1 = non-essential and 2 = essential, specifies the essentiality of inputs from sector k for the production of a firm in sector l
#' @param h_weights n times q matrix, where element ik denotes the weight of firm i in weight type k, if FALSE out strength of firms is used as weight.
#' @param sec_aggr_weights n vector, element i specifies the weight of firm i when shocks are aggregated to the sector level
#' @param sec_aggr_weights_up n vector, element i specifies the weight of firm i when upstream shocks are aggregated to the sector level. Usually this is in-strenght. When sec_aggr_weights_up is provided sec_aggr_weights will be used for downstream shock aggregation.
#' @param psi_mat n times m (sparse) matrix, where element ij takes values between 0 and 1 and specifies the the shock to firm i in scenario j
#' @param psi_mat_up n times m (sparse) matrix, where element ij takes values between 0 and 1 and specifies the the shock to firm i in scenario j that propagates upstream. If psi_mat_up is provided psi_mat will be only used for downstream shocks.
#' @param revenue n vector, element i specifies the revenue of the firm from income state data
#' @param costs n vector, element i specifies the material costs of the firm from income state data
#' @param h_mat_round numeric, rounding threshold for the h_mat matrices (they are usually rather dense and take up lots of space for large networks, hence rounding makes sense)
#' @param track_h logical, should for each scenario ( out of ncol(psi_mat)) the final level of production for each firm be tracked (i.e. h(T)_i for all firms)
#' @param track_sector_impacts logical, if TRUE the shocks to firms are aggregated to the sector level (specified in p_sec_impact) and outputted as sec_du_mat, for easy comparison with shock propagation calculated on the sector level IO tables
#' @param track_conv logical, should the number of iteration steps until convergence be tracked?
#' @param conv_type integer, if conv_type = 1, cascade stops if h(t)-h(t-1) < eps, if conv_type != 1 cascade stops if ESRI(t)/ESRI(t-1) < (1+eps)
#' @param eps numeric, convergence threshold for shock propagation, i.e. when shocks affect the production of firms less than eps shock propagation stops (if conv_type == 1); or if overall loss in production (ESRI) does change less than eps (conv_type != 1)
#' @param use_rcpp logical, if TRUE rcpp implementation from the fastcascade package is used. note that the fastcascade package has to be installed!
#' @param ncores integer, specifies how many cores are used for the parallelisation of the cascade. if FALSE no parallelisation is used.
#' @param run_id character / string, is saved in the runinfo to keep track of what the object is corresponding to.
#' @param load_balance logical, if TRUE load balancing is used in the parallelisation
#' @param Lambda_d_save logical, should the Lambda_d matrix be saved?
#' @param plot_ess_mat_sec_vs_p logical, performs a visual check if rownames of ess_mat_sec and the sectors in p match
#'
#' @return list containing the ESRI, h_mat, ESRI_conv, sec_du_mat, results depending on the inputs to the function
#' @export
#'
#' @examples
#'GL_cascade(W = example_data$W, p = example_data$p,
#'ess_mat_sec =  example_data$ess_mat_sec,
#'track_h = TRUE, track_conv = TRUE, eps = 10^-2,
#'use_rcpp = FALSE, ncores = 0, run_id = "test_cascade" )
#'
GL_cascade <- function(W,
                       p,
                       p_market = FALSE,
                       p_sec_impacts = FALSE,   # sector membership vector, if impacts are aggregated to sector level
                       ess_mat_sec = FALSE,     # must be supplied
                       h_weights = FALSE,       # column matrix of firm weights
                       sec_aggr_weights = FALSE, # vector of firm weights for aggregation to sector level
                       sec_aggr_weights_up = FALSE, # vector of firm weights for aggregation to sector level
                       psi_mat = FALSE,
                       psi_mat_up = FALSE, # if psi_mat up specified, psi_mat --> psi_mat for downstream contagion
                       revenue = FALSE,
                       costs = FALSE,
                       track_h = FALSE,
                       track_sector_impacts = FALSE, # TRUE FALSE if firm impacts are aggregated to sectors
                       track_conv = FALSE,
                       conv_type = 1,
                       eps = 10^-2,
                       h_mat_round = FALSE, #if false will be nchar(1 / eps)
                       use_rcpp = FALSE,
                       ncores = FALSE,
                       run_id = FALSE,
                       load_balance = FALSE,
                       Lambda_d_save = FALSE,
                       plot_ess_mat_sec_vs_p = FALSE
){


  cat("Job started")
  cat("\n")
  cat("\n")



  run_info <- matrix(character(0), ncol=2)
  colnames(run_info) <- c("Info", "Value")
  run_info <- rbind(run_info, c("Run ID", as.character(run_id)))
  run_info <- rbind(run_info, c("Use Rcpp:", as.character(use_rcpp)))
  run_info <- rbind(run_info, c("Number of Cores", as.character(ncores)))
  run_info <- rbind(run_info, c("Convergence Threshold", as.character(eps)))

  if(h_mat_round == FALSE){ h_mat_round <- nchar(1 / eps)}

  # make sure W is a sparse matrix
  W <- Matrix::Matrix(W, sparse = TRUE)


  cat("###############################", "\n")
  cat("### Cascade Run Information ###", "\n")
  cat("###############################", "\n", "\n", "\n")
  starting_time <- Sys.time()
  cat("Starting Time:", as.character(starting_time), "\n", "\n")
  run_info <- rbind(run_info, c("Starting Time", as.character(starting_time)))


  ### compute the necessary variables for the cascade

  # check if dimensions of W and p match

  if(W@Dim[1] == length(p) & W@Dim[2] == length(p)){
    # assign the number of firms
    n <- W@Dim[1]
    print(n)
  }else{
    cat("Dimensions of W and p do not match", W@Dim, length(p), "\n")
  }

  run_info <- rbind(run_info, c("Number of Firms", as.character(n)))


  cat("DIMENSIONS of objects:", "\n", "\n")

  cat(W@Dim, "dimension of W", "\n")
  cat(length(p), "length of p", "\n")
  cat(length(p_market), "length of p_market", "\n")
  cat(length(p_sec_impacts), "length of p_sec_impacts", "\n")
  cat(dim(h_weights), "length of weighting vectors", "\n")
  cat(length(sec_aggr_weights), "length of sector aggregation vector", "\n", "\n")
  cat(length(sec_aggr_weights_up), "length of sector aggregation vector upstream", "\n", "\n")


  cat("Are sectors in p and ess_mat_sec aligned:", "\n")
  if((length(unique(p))!= dim(ess_mat_sec)[2])| length(unique(p))!= dim(ess_mat_sec)[1]){
    cat("ERROR warning: number of sectors in p not in line with ess_mat_sec", "\n")
  }

  cat("Are sectors in p and ess_mat_sec having the same names:", "\n")
  if( length( which( ( sort(unique(p)) == (rownames(ess_mat_sec)) ) == FALSE)) > 0 ){
    cat("WARNING: names of sectors in p are not the same as rownames in ess_mat_sec", "\n")
    cat("trying to allign them by using as.numeric functions to avoid leading zeros in nace codes", "\n")

    p <- as.numeric(p)
    colnames(ess_mat_sec) <- rownames(ess_mat_sec) <- as.numeric(rownames(ess_mat_sec))

    if(length( which( ( sort(unique(p)) == (rownames(ess_mat_sec)) ) == FALSE)) == 0 ){
      cat("problem fixed", "\n")
    }

  }

  if(plot_ess_mat_sec_vs_p == TRUE){
    if( length(colnames(ess_mat_sec))>0){
      plot(as.numeric(colnames(ess_mat_sec)) - as.numeric(sort(unique(p))),
           ylab = "sector sorting difference", xlab="sector index",
           main="optimally you see a zero line:")
      cat("sectors in ess_mat_sec must be in same order as sort(unique(p)). check if plot is a 0 line", "\n")
    }else{
      cat("names of ess_mat_sec are missing. can not check if columns are in correct order.", "\n")
    }
  }







  # check if supplier replaceability is considered
  if(length(p_market)<=1){
    substitution <- FALSE
    cat("Supplier replaceability is NOT used", "\n")
  }else{
    substitution <- TRUE
    cat("Supplier replaceability is used", "\n")
    if(length(p_market) != n){
      cat("wrong length of p_market:", length(p_market), "\n")
    }
  }
  run_info <- rbind(run_info, c("Nr. Market Share Sectors (p_market)",
                                as.character(length(unique(p_market)))))

  # Check if only as subset of companies should be analyzed
  if(length(psi_mat)<=1){
    cat(paste(n, "single firm ESRI are computed."), "\n")
    psi_mat <- Matrix::Diagonal(n = n)
  }else{
    cat(paste(ncol(psi_mat), "multi firm ESRI scenarios are computed."), "\n")
  }
  run_info <- rbind(run_info, c("Number of Shock Scenarios (psi_mat)",
                                as.character(ncol(psi_mat))))

  if(length(psi_mat_up) > 1){
    run_info <- rbind(run_info, c("psi_mat_up was submitted"))
    cat("psi_mat_up was submitted: ")
    cat(paste("\n dim(psi_mat) == dim(psi_mat_up)", dim(psi_mat) == dim(psi_mat_up)))
  }else{   # if psi_mat_up is not submitted use psi_mat for down and upstream
    psi_mat_up <- psi_mat
  }



  # are shocks aggregated to the sector level
  if(track_sector_impacts == TRUE){
    cat("Sector impacts are aggregated for", length(unique(p_sec_impacts)),
        "different sectors", "\n")
    if(length(p_sec_impacts) != n){
      cat("wrong length of p_sec_impacts:", length(p_market), "\n")
    }
  }else{
    cat("Sector impacts of shocks are not analyzed", "\n")
    p_sec_impacts <- rep(1,n) # this is a quick fix which should be exchanged by adressing the issue in the cpp code
  }
  run_info <- rbind(run_info, c("Number of Sectors for Shock Aggregation",
                                as.character(length(unique(p_sec_impacts)))))


  ### transform sectors into consecutive indices

  sectors <- sort(unique(p))
  m <- length(sectors)
  cat(m, "industry sectors contained in p", "\n")
  cat(dim(ess_mat_sec), "dimension of ess_mat_sec", "\n")


  sectors_cons <- 1:length(sectors)
  names(sectors_cons) <- sectors
  p_cons <- unname(sectors_cons[as.character(p)])

  psup <- Matrix::sparseMatrix(i = 1:n,
                               j = p_cons,
                               dims = c(n, m))

  # matrix n times m that contains the inputs used by each firm
  pi_abs <- Matrix::crossprod(W, psup)



  if(substitution == TRUE){
    # transform sectors into consecutive indices for market share calcualtion
    sectors_market <- sort(unique(p_market))
    sectors_market_cons <- 1:length(sectors_market) # indices of p_market sectors for matrices
    names(sectors_market_cons) <- sectors_market

    p_market_cons <- unname(sectors_market_cons[as.character(p_market)])

    m_market <- length(unique(p_market))

    psup_market <- Matrix::sparseMatrix(i = 1:n,
                                j = p_market_cons,
                                dims = c(n, m_market))
  }else{
    p_market_cons <- rep(1, n)
    psup_market <- Matrix::Matrix(0, ncol = length(unique(p_market)), nrow = n)
  }


  if(track_sector_impacts){
    # transform sectors into consecutive indices for sector aggregation
    sectors_sec_imp <- sort(unique(p_sec_impacts))
    sectors_sec_imp_cons <- 1:length(sectors_sec_imp) # indices of p_sec_impacts sectors for matrices
    names(sectors_sec_imp_cons) <- sectors_sec_imp

    p_sec_impacts_cons <- unname(sectors_sec_imp_cons[as.character(p_sec_impacts)])

    m_sec_imp <- length(unique(p_sec_impacts))

    psup_sec_impact <- Matrix::sparseMatrix(i = 1:n,
                                    j = p_sec_impacts_cons,
                                    dims = c(n, m_sec_imp))
  }else{
    #psup_sec_impact <- Matrix(0, ncol = length(unique(p_sec_impacts)), nrow = n)
    psup_sec_impact <- Matrix::Matrix(0, ncol = 1, nrow = n)

  }


  ### make calculation of GL production function more efficient by jointly updating different sectors with same set of essential and non essential inputs

  # the unique essential non essential vectors of all industry sectors
  uni_ess_mat_sec <- unique(as.matrix(ess_mat_sec), MARGIN=2)
  # the column index of the uni_ess_mat_sec matrix rather than the original industry sector
  sector_cons_uni_ess_mat <- numeric(length(sectors_cons)) # m_cons

  # check for each sector in p, if their essential supplier sets are unique
  for(k in 1:dim(uni_ess_mat_sec)[2]){
    ess_duplicates <- apply(ess_mat_sec, MARGIN = 2, function(x) identical(uni_ess_mat_sec[,k], x) )
    sector_cons_uni_ess_mat[ess_duplicates] <- k
  }
  names(sector_cons_uni_ess_mat) <- sectors_cons

  # create the vector with sectors corresponding to unique essential supplier sets
  p_cons_uni_ess_mat <- sector_cons_uni_ess_mat[as.character(p_cons)]


  cat("number of unique essential/non-essential sets: ", dim(uni_ess_mat_sec)[2], "\n")
  run_info <- rbind(run_info, c("number of unique essential/non-essential sets: ", dim(uni_ess_mat_sec)[2]))
  run_info <- rbind(run_info, c("number of essential sector links: ", sum(ess_mat_sec == 2)))
  run_info <- rbind(run_info, c("number of non-essential sector links: ", sum(ess_mat_sec == 1)))
  run_info <- rbind(run_info, c("number of unimportant sector links: ", sum(ess_mat_sec == 0)))



  # outstrength and instrength
  out_str <- Matrix::rowSums(W)
  in_str <-  Matrix::colSums(W)

  # if no h_weights are given use outstrength
  if(length(h_weights) <= 1){
    #weights_output <- FALSE
    h_weights <- cbind(out_str)
    cat("No weights for h are supplied. Using out-strength.", "\n")

  }else{
    cat(dim(h_weights)[2], "weight vectors were supplied", "\n")
    #weights_output <- dim(h_weights)[2]
  }
  run_info <- rbind(run_info, c("Number of Weights", as.character(dim(h_weights)[2])))


  # save how many weight vectors are used
  n_weights <- dim(h_weights)[2]

  if(length(sec_aggr_weights) <= 1){
    # if no specific weights for sector aggregation of shocks is supplied use, first weight from overall aggregation
    sec_aggr_weights <- h_weights[,1]

    cat("No weights for sector aggregation are supplied. Using h_weights[,1].", "\n")
  }else{
    cat("Sector aggregation weights were supplied.", "\n")
  }

  if(length(sec_aggr_weights_up) <= 1){
    # if no specific weights for sector aggregation of shocks is supplied use, first weight from overall aggregation, such that aggregation of shocks yields same as esri upstream
    sec_aggr_weights_up <- h_weights[,1]

    cat("No weights for sector aggregation upstream are supplied. Using h_weights[,1].", "\n")
  }else{
    cat("Sector aggregation weights upstream were supplied.", "\n")
  }



  ### calculate downstream propagation matrix
  timerl <- Sys.time()

  # Lambda_d <- Lambda_d_calc_r_with_prep(W = W,
  #                                       p = p_cons,
  #                                       ess_mat_sec = ess_mat_sec,
  #                                       pi_abs = pi_abs,
  #                                       in_str = in_str,
  #                                       mix_prodfun = mix_prodfun,
  #                                       serv_supp = serv_supp,
  #                                       prodfun_sets = prodfun_sets, # kill
  #                                       serv_supplier_sets = serv_supplier_sets, # kill
  #                                       pf_type = pf_type,
  #                                       m = m,
  #                                       n = n)

  # replaced above  to delete prodfun_sets and serv_supplier_sets
  Lambda_d <- Lambda_d_calc_r(W = W,
                              p = p,
                              p_cons = p_cons,
                              ess_mat_sec = ess_mat_sec,
                              pi_abs = pi_abs,
                              in_str = in_str,
                              n = n)

  run_info <- rbind(run_info, c("Lambda Calculation Time", as.character(round(Sys.time()-timerl,2))))

  if(Lambda_d_save == TRUE){
    saveRDS(Lambda_d, paste0("Lambda_", run_id, "_size_", n, ".rds"))
  }


  ### adjustment for overestimating link importance from reporting threshold

  if(length(revenue)>1){
    Lambda_u <- W /( (revenue==0)*1 + (revenue>0)*revenue )
  }else{
    Lambda_u <- W /( (out_str==0)*1 + (out_str>0)*out_str )
  }
  run_info <- rbind(run_info, c("Revenue Adjustment", as.character(length(revenue)>1)))

  if(length(costs)>1){
    Lambda_d <- Matrix::t( Matrix::t(Lambda_d) * ( ( (in_str==0)*1 + (in_str>0)*in_str )/ #if instr =0 nodes are unchagned
                                     ( (costs==0)*1 + (costs>0)*costs) ) )
  }
  run_info <- rbind(run_info, c("Cost Adjustment", as.character(length(costs)>1)))



  ### prepare matrices to save results/outputs from cascade
  # future --> use names from h_weights matrix
  ESRI <- Matrix::Matrix(0, nrow = ncol(psi_mat), ncol=3*n_weights)
  colnames(ESRI) <- as.vector(sapply(1:n_weights, function(k) paste0(c("ESRI", "ESRI_d", "ESRI_u"), paste0("_weight_", k))))

  ESRI_conv <- Matrix::Matrix(0, nrow = ncol(psi_mat), ncol=3)
  colnames(ESRI_conv) <- c("ESRI_T-1", "ESRI_T", "T")

  if(track_h==TRUE){
    cat("Single h vectors are tracked", "\n")
    hd_T_mat <- Matrix::Matrix(0, ncol=ncol(psi_mat), nrow=n) # matrix where downstream shocks h^d(T) vector will be stored for each default scenario
    hu_T_mat <- Matrix::Matrix(0, ncol=ncol(psi_mat), nrow=n) # matrix where upstream shocks  h^u(T) vector will be stored for each default scenario
  }

  if(track_sector_impacts==TRUE){
    cat("Sector impacts are tracked", "\n") # each row one sceario, each column corresponds to one sector
    sec_d_mat  <- Matrix::Matrix(0, nrow=ncol(psi_mat), ncol=ncol(psup_sec_impact))
    sec_u_mat  <- Matrix::Matrix(0, nrow=ncol(psi_mat), ncol=ncol(psup_sec_impact))
    sec_du_mat <- Matrix::Matrix(0, nrow=ncol(psi_mat), ncol=ncol(psup_sec_impact))

    # track the initial perecntage shock of each sector
    sec_d_mat_init  <- Matrix::Matrix(0, nrow=ncol(psi_mat), ncol=ncol(psup_sec_impact))
    sec_u_mat_init  <- Matrix::Matrix(0, nrow=ncol(psi_mat), ncol=ncol(psup_sec_impact))
    sec_du_mat_init <- Matrix::Matrix(0, nrow=ncol(psi_mat), ncol=ncol(psup_sec_impact))

  }



  #==============================================================================#
  ###################### default cascade simulation ##############################
  #==============================================================================#


  cat("\n")
  timer <- as.character(Sys.time())
  cat("Start Cascade Calculation", timer, "\n")


  if(ncores==FALSE){# compute regularly on one core
    if(use_rcpp==FALSE){
      output_mat <- GL_cascade_dynamics(Lambda_d = Lambda_d,
                                        Lambda_u = Lambda_u,
                                        psup = psup,
                                        psup_market = psup_market,
                                        psi_mat = psi_mat,
                                        psi_mat_up = psi_mat_up,
                                        n = n,
                                        m = m,
                                        eps = eps,
                                        h_mat_round = h_mat_round,
                                        track_h = track_h,
                                        h_weights = h_weights,
                                        out_str = out_str,
                                        p_market_cons = p_market_cons,
                                        substitution = substitution,
                                        track_conv = track_conv,
                                        conv_type = conv_type,
                                        track_sector_impacts = track_sector_impacts,
                                        psup_sec_impact = psup_sec_impact,
                                        sec_aggr_weights = sec_aggr_weights,
                                        sec_aggr_weights_up = sec_aggr_weights_up,
                                        sectors_cons = sectors_cons,
                                        p_cons_uni_ess_mat = p_cons_uni_ess_mat,
                                        uni_ess_mat_sec = uni_ess_mat_sec
      ) # result of i defaulting in column i
    }else
    {
      # preprocessing for RcppArmadillo in
      p_market_cons <- p_market_cons - 1 # change index to cpp convention
      p_cons_uni_ess_mat <- p_cons_uni_ess_mat - 1
      #prodfun_set_1 <- (prodfun_sets==1)*1
      #prodfun_set_2 <- (prodfun_sets==2)*1

      Lambda_d <- Matrix::Matrix(Lambda_d, sparse=TRUE)
      Lambda_u <- Matrix::Matrix(Lambda_u, sparse=TRUE)

      psup <- Matrix::Matrix(psup * 1, sparse=TRUE)
      psup_market <- Matrix::Matrix(psup_market * 1, sparse=TRUE)
      psup_sec_impact <- Matrix::Matrix(psup_sec_impact * 1, sparse=TRUE)

      psi_mat <- Matrix::Matrix(psi_mat, sparse=TRUE)
      psi_mat_up <- Matrix::Matrix(psi_mat_up, sparse=TRUE)


      output_mat <- fastcascade::GL_cascade_dynamics_cpp(Lambda_d = Lambda_d,
                                            Lambda_u = Lambda_u,
                                            psi_mat = psi_mat,
                                            psi_mat_up = psi_mat_up,
                                            n = n,
                                            m = m,
                                            substitution = substitution,
                                            psup = psup,
                                            h_weights = h_weights,
                                            eps = eps,
                                            h_mat_round = h_mat_round,
                                            p_market_cons = p_market_cons,
                                            out_str = out_str,
                                            psup_market = psup_market,
                                            track_h = track_h,
                                            track_sector_impacts = track_sector_impacts,
                                            track_conv = track_conv,
                                            conv_type = conv_type,
                                            psup_sec_impact = psup_sec_impact,
                                            sec_aggr_weights = sec_aggr_weights,
                                            sec_aggr_weights_up = sec_aggr_weights_up,
                                            sectors_cons = sectors_cons,
                                            p_cons_uni_ess_mat = p_cons_uni_ess_mat,
                                            uni_ess_mat_sec = uni_ess_mat_sec)
    }


  }else{ # if more cores are available calculate on a socket cluster (default type, "PSOCK")

    cl <- parallel::makeCluster(ncores, type = "PSOCK") # on Unix you can change type to "FORK" # make a switch with Sys.info()[1]


    if(use_rcpp == TRUE){
      cat("use_rcpp")

      # preprocessing for RcppArmadillo in
      p_market_cons <- p_market_cons-1 # change index to cpp convention
      p_cons_uni_ess_mat <- p_cons_uni_ess_mat-1

      #prodfun_set_1 <- (prodfun_sets==1)*1
      #prodfun_set_2 <- (prodfun_sets==2)*1

      Lambda_d <- Matrix::Matrix(Lambda_d, sparse=TRUE)
      Lambda_u <- Matrix::Matrix(Lambda_u, sparse=TRUE)

      psup <- Matrix::Matrix(psup * 1, sparse=TRUE)
      psup_market <- Matrix::Matrix(psup_market * 1, sparse=TRUE)
      psup_sec_impact <- Matrix::Matrix(psup_sec_impact * 1, sparse=TRUE)

    }
    psi_mat <- Matrix::Matrix(psi_mat, sparse = TRUE)
    psi_mat_up <- Matrix::Matrix(psi_mat_up, sparse = TRUE)

    # split the scenarios into chunks for each core for downstream and upstream shocks
    psi_mat_splits_down <- split_mat(psi_mat, ncores, load_balance)
    psi_mat_splits_up <- split_mat(psi_mat_up, ncores, load_balance)

    psi_mat_splits <- lapply(1:length(psi_mat_splits_down), function(x) c(psi_mat_splits_down[x], psi_mat_splits_up[x]))


    parallel::clusterExport(cl, list("W",
                           "p_cons_uni_ess_mat",
                           "sectors_cons",
                           "Lambda_d",
                           "Lambda_u",
                           "psup",
                           "n",
                           "m",
                           "GL_cascade_dynamics",
                           "eps",
                           "h_mat_round",
                           "h_weights",
                           "track_h",
                           #"prodfun_sets",
                           #"mix_prodfun",
                           "psup_market",
                           "out_str",
                           "p_market_cons",
                           "substitution",
                           "track_conv",
                           "conv_type",
                           "track_sector_impacts",
                           "psup_sec_impact",
                           "sec_aggr_weights",
                           "sec_aggr_weights_up",
                           "uni_ess_mat_sec")
                  , envir = environment())

    parallel::clusterEvalQ(cl, list(library(Matrix), library(Rcpp), library(RcppArmadillo)))

    if(use_rcpp==FALSE){

      if(load_balance == FALSE){
        casc_list <- parallel::parLapply(cl, psi_mat_splits,
                               function(psi_mat) GL_cascade_dynamics(Lambda_d = Lambda_d,
                                                                     Lambda_u = Lambda_u,
                                                                     psup = psup,
                                                                     psup_market = psup_market,
                                                                     psi_mat = psi_mat[[1]], # normal or downstream
                                                                     psi_mat_up = psi_mat[[2]], # upstream
                                                                     n = n,
                                                                     m = m,
                                                                     eps = eps,
                                                                     h_mat_round = h_mat_round,
                                                                     track_h = track_h,
                                                                     h_weights = h_weights,
                                                                     out_str = out_str,
                                                                     p_market_cons = p_market_cons,
                                                                     substitution = substitution,
                                                                     track_conv = track_conv,
                                                                     conv_type = conv_type,
                                                                     track_sector_impacts = track_sector_impacts,
                                                                     psup_sec_impact = psup_sec_impact,
                                                                     sec_aggr_weights = sec_aggr_weights,
                                                                     sec_aggr_weights_up = sec_aggr_weights_up,
                                                                     sectors_cons = sectors_cons,
                                                                     p_cons_uni_ess_mat = p_cons_uni_ess_mat,
                                                                     uni_ess_mat_sec = uni_ess_mat_sec
                               )
        )
      }else{ # load balance = TRUE
        casc_list <- parallel::parLapplyLB(cl, psi_mat_splits,
                                 function(psi_mat) GL_cascade_dynamics(Lambda_d = Lambda_d,
                                                                       Lambda_u = Lambda_u,
                                                                       psup = psup,
                                                                       psup_market = psup_market,
                                                                       psi_mat = psi_mat[[1]], # normal or downstream
                                                                       psi_mat_up = psi_mat[[2]], # upstream
                                                                       n = n,
                                                                       m = m,
                                                                       eps = eps,
                                                                       h_mat_round = h_mat_round,
                                                                       track_h = track_h,
                                                                       h_weights = h_weights,
                                                                       out_str = out_str,
                                                                       p_market_cons = p_market_cons,
                                                                       substitution = substitution,
                                                                       track_conv = track_conv,
                                                                       conv_type = conv_type,
                                                                       track_sector_impacts = track_sector_impacts,
                                                                       psup_sec_impact = psup_sec_impact,
                                                                       sec_aggr_weights = sec_aggr_weights,
                                                                       sec_aggr_weights_up = sec_aggr_weights_up,
                                                                       sectors_cons = sectors_cons,
                                                                       p_cons_uni_ess_mat = p_cons_uni_ess_mat,
                                                                       uni_ess_mat_sec = uni_ess_mat_sec
                                 )
        )
      }

    } else { # cpp TRUE
      parallel::clusterEvalQ(cl, list(library(Matrix), library(fastcascade), library(Rcpp), library(RcppArmadillo)))

      # need to change those things before transferring to cluster nodes
      # # preprocessing for RcppArmadillo in
      # p_market_cons <- p_market_cons-1 # change index to cpp convention
      # p_cons_uni_ess_mat <- p_cons_uni_ess_mat-1
      #
      # #prodfun_set_1 <- (prodfun_sets==1)*1
      # #prodfun_set_2 <- (prodfun_sets==2)*1
      #
      # Lambda_d <- Matrix::Matrix(Lambda_d, sparse=TRUE)
      # Lambda_u <- Matrix::Matrix(Lambda_u, sparse=TRUE)
      #
      # psup <- Matrix::Matrix(psup * 1, sparse=TRUE)
      # psup_market <- Matrix::Matrix(psup_market * 1, sparse=TRUE)
      # psup_sec_impact <- Matrix::Matrix(psup_sec_impact * 1, sparse=TRUE)
      #
      # psi_mat <- Matrix::Matrix(psi_mat, sparse = TRUE)

      if(load_balance == FALSE){
        casc_list <- parallel::parLapply(cl, psi_mat_splits,
                               function(psi_mat) fastcascade::GL_cascade_dynamics_cpp(Lambda_d = Lambda_d,
                                                                         Lambda_u = Lambda_u,
                                                                         psi_mat = psi_mat[[1]],
                                                                         psi_mat_up = psi_mat[[2]],
                                                                         n = n,
                                                                         m = m,
                                                                         substitution = substitution,
                                                                         psup = psup,
                                                                         h_weights = h_weights,
                                                                         eps = eps,
                                                                         h_mat_round = h_mat_round,
                                                                         p_market_cons = p_market_cons,
                                                                         out_str = out_str,
                                                                         psup_market = psup_market,
                                                                         track_h = track_h,
                                                                         track_sector_impacts = track_sector_impacts,
                                                                         track_conv = track_conv,
                                                                         conv_type = conv_type,
                                                                         psup_sec_impact = psup_sec_impact,
                                                                         sec_aggr_weights = sec_aggr_weights,
                                                                         sec_aggr_weights_up = sec_aggr_weights_up,
                                                                         sectors_cons = sectors_cons,
                                                                         p_cons_uni_ess_mat = p_cons_uni_ess_mat,
                                                                         uni_ess_mat_sec = uni_ess_mat_sec
                               )
        )

      }else{ # load balance = TRUE
        casc_list <- parallel::parLapplyLB(cl, psi_mat_splits,
                                 function(psi_mat) fastcascade::GL_cascade_dynamics_cpp(Lambda_d = Lambda_d,
                                                                           Lambda_u = Lambda_u,
                                                                           psi_mat = psi_mat[[1]],
                                                                           psi_mat_up = psi_mat[[2]],
                                                                           n = n,
                                                                           m = m,
                                                                           substitution = substitution,
                                                                           psup = psup,
                                                                           h_weights = h_weights,
                                                                           eps = eps,
                                                                           h_mat_round = h_mat_round,
                                                                           p_market_cons = p_market_cons,
                                                                           out_str = out_str,
                                                                           psup_market = psup_market,
                                                                           track_h = track_h,
                                                                           track_sector_impacts = track_sector_impacts,
                                                                           track_conv = track_conv,
                                                                           conv_type = conv_type,
                                                                           psup_sec_impact = psup_sec_impact,
                                                                           sec_aggr_weights = sec_aggr_weights,
                                                                           sec_aggr_weights_up = sec_aggr_weights_up,
                                                                           sectors_cons = sectors_cons,
                                                                           p_cons_uni_ess_mat = p_cons_uni_ess_mat,
                                                                           uni_ess_mat_sec = uni_ess_mat_sec
                                 )
        )

      }# end if load_balance == FALSE

          }# end if use_rcpp == FALSE

    parallel::stopCluster(cl)


    #==============================================================================#
    ###################### post cluster clean up ##############################
    #==============================================================================#

    timer <- as.character(Sys.time())
    cat("post cluster calculation", timer, "\n", "\n")

    #cat("save result from cluster", "\n")
    #saveRDS(casc_list, paste0(run_id, as.character(Sys.Date()) ,"_cluster_result.RDS"))

    #core_dims <- cumsum(c(0,sapply(psi_mat_splits, function(x) ncol(x))))

    timer_pstclst <- as.character(Sys.time())
    cat("unlist results to single matrix", timer_pstclst, "\n")


    # gather the results from single cores into one large sparse matrix
    output_mat <- do.call(rbind, casc_list)
  }

  # define column ranges for the seperate outputs
  cluster_output_col_range <- c(1,
                                3*n_weights,              # ESRI columns
                                if(track_h){n}else{0},    # h_d matrix
                                if(track_h){n}else{0},    # h_u matrix
                                if(track_conv){3}else{0}, # track convergence
                                if(track_sector_impacts){ncol(psup_sec_impact)}else{0}, # sector shock down stream # put same for initial shock
                                if(track_sector_impacts){ncol(psup_sec_impact)}else{0}, # sector shock up stream # put same for initial shock
                                if(track_sector_impacts){ncol(psup_sec_impact)}else{0}, # sector shock up and down merged)
                                if(track_sector_impacts){ncol(psup_sec_impact)}else{0}, # sector shock down stream # put same for initial shock
                                if(track_sector_impacts){ncol(psup_sec_impact)}else{0}, # sector shock up stream # put same for initial shock
                                if(track_sector_impacts){ncol(psup_sec_impact)}else{0}  # sector shock up and down merged)
  )
  if(ncol(output_mat)==(sum(cluster_output_col_range)-1)){
    cat("column dimensions match", "\n")
  }else{cat("ERROR ERROR ERROR, dimensions wrong, ERROR ERROR ERROR")}

  st_ind <- cumsum(cluster_output_col_range[-length(cluster_output_col_range)])
  en_ind <- cumsum(cluster_output_col_range[-1])

  # progress messages
  cat("split the large output matrix", "\n")
  timer <- as.character(Sys.time())
  cat("ESRI", timer, "\n")

  ESRI[,] <- output_mat[,st_ind[1]:en_ind[1], drop=FALSE]

  if(track_h==TRUE){
    timer <- as.character(Sys.time())
    cat("track_h", timer, "\n")
    hd_T_mat <- output_mat[,st_ind[2]:en_ind[2], drop=FALSE]
    hu_T_mat <- output_mat[,st_ind[3]:en_ind[3], drop=FALSE]
  }


  if(track_conv==TRUE){
    timer <- as.character(Sys.time())
    cat("track convergence", timer, "\n")
    ESRI_conv[,] <- output_mat[,st_ind[4]:en_ind[4], drop=FALSE]
  }

  if(track_sector_impacts==TRUE){
    timer <- as.character(Sys.time())
    cat("track sector impact down", timer, "\n")
    sec_d_mat <- output_mat[,st_ind[5]:en_ind[5], drop=FALSE]
    colnames(sec_d_mat) <-  sectors_sec_imp

    timer <- as.character(Sys.time())
    cat("track sector impact up", timer, "\n")
    sec_u_mat <- output_mat[,st_ind[6]:en_ind[6], drop=FALSE]
    colnames(sec_u_mat) <-  sectors_sec_imp

    timer <- as.character(Sys.time())
    cat("track sector impact merged", timer, "\n")
    sec_du_mat <- output_mat[,st_ind[7]:en_ind[7], drop=FALSE]
    colnames(sec_du_mat) <-  sectors_sec_imp


    timer <- as.character(Sys.time())
    cat("track initial sector impact down", timer, "\n")
    sec_d_mat_init <- output_mat[,st_ind[8]:en_ind[8], drop=FALSE]
    colnames(sec_d_mat_init) <-  sectors_sec_imp

    timer <- as.character(Sys.time())
    cat("track initial sector impact up", timer, "\n")
    sec_u_mat_init <- output_mat[,st_ind[9]:en_ind[9], drop=FALSE]
    colnames(sec_u_mat_init) <-  sectors_sec_imp

    timer <- as.character(Sys.time())
    cat("track initial sector impact merged", timer, "\n")
    sec_du_mat_init <- output_mat[,st_ind[10]:en_ind[10], drop=FALSE]
    colnames(sec_du_mat_init) <-  sectors_sec_imp

  }



  timer <- as.character(Sys.time())
  cat("Assemble single output matrices into a list", timer, "\n")
  # set the output variables
  output_list <- list(ESRI = ESRI)

  if(track_h==TRUE){
    output_list <- c(output_list,
                     hd_T_mat = Matrix::t(hd_T_mat), # transpose back; column contains shocks everyone receives after shock scenario in column i
                     hu_T_mat = Matrix::t(hu_T_mat)
    )
  }

  if(track_conv==TRUE){
    output_list <- c(output_list,
                     ESRI_conv = ESRI_conv
    )
  }

  if(track_sector_impacts==TRUE){
    output_list <- c(output_list,
                     sec_d_mat = sec_d_mat,
                     sec_u_mat = sec_u_mat,
                     sec_du_mat = sec_du_mat,
                     sec_d_mat_init = sec_d_mat_init,
                     sec_u_mat_init = sec_u_mat_init,
                     sec_du_mat_init = sec_du_mat_init
    )
  }

  # cat("Postcluster Time Difference:")
  # print(Sys.time()-timer_pstclst)
  cat("\n")
  #}

  timer <- as.character(Sys.time())
  cat("Merge Outputs Finished", timer, "\n")


  cat("\n")
  cat("Job Finished after a")
  print(Sys.time()-starting_time)
  cat("\n")
  run_info <- rbind(run_info, c("Calculation Time in mins:", difftime(Sys.time(),starting_time, units="min")))
  output_list$run_info <- run_info

  return(output_list)
}


# worker function

#' R implementation of the up- and down-stream shock propagation dynamics of the GL cascade
#'
#' @param Lambda_d sparse n times n sparse matrix, Lambda_d, where element ij specifies the fraction of production firm j loses if supplier i can not deliver any goods and services of type p_i to firm j anymore.
#' @param Lambda_u sparse n times n sparse matrix, Lambda_u, where element ij specifies the fraction of production firm j loses if customer i can not demand any goods and services of type p_j to firm i anymore.
#' @param psup n times m sparse matrix, where element ik is 1 if firm i is in sector k (i.e. p_i = k) and zero else. its useful for aggregation according to sectors
#' @param psup_market n times m sparse matrix, where element ik is 1 if firm i is in sector k (p_market_i = k) and zero else. its useful for aggregation according to sectors
#' @param psi_mat n times m (sparse) matrix, where element ij takes values between 0 and 1 and specifies the the shock to firm i in scenario j
#' @param psi_mat_up n times m (sparse) matrix, where element ij takes values between 0 and 1 and specifies the the shock to firm i in scenario j that propagates upstream. If psi_mat_up is provided psi_mat will be only used for downstream shocks.
#' @param n integer, the number of firms
#' @param m integer, the number of sectors (i.e. length(unique(p)))
#' @param eps numeric, convergence threshold for shock propagation, i.e. when shocks affect the production of firms less than eps shock propagation stops (if conv_type == 1); or if overall loss in production (ESRI) does change less than eps (conv_type != 1)
#' @param h_mat_round numeric, rounding threshold for the h_mat matrices (they are usually rather dense and take up lots of space for large networks, hence rounding makes sense)
#' @param track_h logical, should for each scenario ( out of ncol(psi_mat)) the final level of production for each firm be tracked (i.e. h(T)_i for all firms)
#' @param h_weights n times q matrix, where element ik denotes the weight of firm i in weight type k, if FALSE out strength of firms is used as weight.
#' @param out_str n vector, element i denotes the out strength of firm i
#' @param p_market_cons n vector, gives the sector affiliation of firm i for the market share calculation in the replaceability factor sigma_i (see paper)
#' @param substitution logical, specifies if the replaceability factor, based on market share of firm i, should be used
#' @param track_conv logical, should the number of iteration steps until convergence be tracked?
#' @param conv_type integer, if conv_type = 1, cascade stops if h(t)-h(t-1) < eps, if conv_type != 1 cascade stops if ESRI(t)/ESRI(t-1) < (1+eps)
#' @param track_sector_impacts  logical, if TRUE the shocks to firms are aggregated to the sector level (specified in p_sec_impact) and outputted as sec_du_mat, for easy comparison with shock propagation calculated on the sector level IO tables
#' @param psup_sec_impact n times m sparse matrix, where element ik is 1 if firm i is in sector k (p_sec_impacts_i = k) and zero else. its useful for aggregation according to sectors
#' @param sec_aggr_weights n vector, element i specifies the weight of firm i when shocks are aggregated to the sector level. Usually this is out-strength
#' @param sec_aggr_weights_up n vector, element i specifies the weight of firm i when upstream shocks are aggregated to the sector level. Usually this is in-strenght. When sec_aggr_weights_up is provided sec_aggr_weights will be used for downstream shock aggregation.
#' @param sectors_cons m vector, sectors matched to 1:m i.e. sector A0111 is consecutive sector 1, sector U9900 is mapped to m (for NACE 4 digit codes)
#' @param p_cons_uni_ess_mat n vector, element i indicates to which group of firms with unique essential non essential inputs it belongs, i.e. to which column in the uni_ess_mat_sec the firm belongs
#' @param uni_ess_mat_sec m times l matrix, with the unique columns of the ess_sec_mat matrix. it is used to enhance computation speed by grouping calculations for sectors with same set of essential and non-essential inputs
#'
#' @return list containing the ESRI, h_mat, ESRI_conv, sec_du_mat, results depending on the inputs to the function
#'
#'
#'
GL_cascade_dynamics <- function(Lambda_d = Lambda_d,
                                Lambda_u = Lambda_u,
                                psup = psup,
                                psup_market = psup_market,
                                psi_mat = psi_mat,
                                psi_mat_up = psi_mat_up,
                                n = n,
                                m = m,
                                eps = eps,
                                h_mat_round = h_mat_round,
                                track_h = track_h,
                                h_weights = h_weights,
                                out_str = out_str,
                                p_market_cons = p_market_cons,
                                substitution = substitution,
                                track_conv = track_conv,
                                conv_type = conv_type,
                                track_sector_impacts = track_sector_impacts,
                                psup_sec_impact = psup_sec_impact,
                                sec_aggr_weights = sec_aggr_weights,
                                sec_aggr_weights_up = sec_aggr_weights_up,
                                sectors_cons = sectors_cons,
                                p_cons_uni_ess_mat = p_cons_uni_ess_mat,
                                uni_ess_mat_sec = uni_ess_mat_sec
){

  # check how many companies need to be calculated on this node
  n_def <- ncol(psi_mat)
  # check how many different weights are used for ESRI calculation
  n_weights <- dim(h_weights)[2]
  # how many unique sets of essential and non essential inputs do we have for GL prodfun
  n_uni_ess_mat_secs <- dim(uni_ess_mat_sec)[2]  #length(unique(p_cons_uni_ess_mat))

  h_weights <- Matrix::t( Matrix::t(h_weights) / colSums(h_weights)) # standardize h_weights to avoid division by the respective column sum below

  sec_aggr_weights    <- sec_aggr_weights    / sum(sec_aggr_weights)
  sec_aggr_weights_up <- sec_aggr_weights_up / sum(sec_aggr_weights_up) # upstream aggregation weights



  if(track_h==TRUE){ # create matrices to save h vectors
    hd_T_mat <- Matrix::Matrix(0, ncol=n_def, nrow=n) # matrix where downstream shocks h^d(T) vector will be stored for each default scenario
    hu_T_mat <- Matrix::Matrix(0, ncol=n_def, nrow=n) # matrix where upstream shocks  h^u(T) vector will be stored for each default scenario
  }

  if(track_sector_impacts==TRUE){
    p_sector_shares <- (sec_aggr_weights) %*% psup_sec_impact # relative share
    p_sector_shares <- ifelse(p_sector_shares > 0, p_sector_shares, 1) # avoid div by 0

    p_sector_shares_up <- (sec_aggr_weights_up) %*% psup_sec_impact # relative share
    p_sector_shares_up <- ifelse(p_sector_shares_up > 0, p_sector_shares_up, 1) # avoid div by 0


    sec_d_mat  <- Matrix::Matrix(0, nrow=n_def, ncol=ncol(psup_sec_impact))
    sec_u_mat  <- Matrix::Matrix(0, nrow=n_def, ncol=ncol(psup_sec_impact))
    sec_du_mat <- Matrix::Matrix(0, nrow=n_def, ncol=ncol(psup_sec_impact))

    sec_d_mat_init  <- Matrix::Matrix(0, nrow=n_def, ncol=ncol(psup_sec_impact))
    sec_u_mat_init  <- Matrix::Matrix(0, nrow=n_def, ncol=ncol(psup_sec_impact))
    sec_du_mat_init <- Matrix::Matrix(0, nrow=n_def, ncol=ncol(psup_sec_impact))
  }

  # output matrices for Systemic Risk Index and convergence statistics
  ESRI <- Matrix::Matrix(0, ncol = 3*n_weights, nrow = n_def)
  ESRI_conv <- Matrix::Matrix(0, ncol = 3, nrow = n_def)


  for(i in 1:n_def){
    # progress report for single core
    if((i %% 100)==0){
      timer <- as.character(Sys.time())
      cat("iteration", i, timer, "   ")
    }


    #h_tm1_d <- rep(1,n)
    #h_tm1_u <- rep(1,n)
    # h_t_d  <- rep(1,n)
    # h_t_u  <- rep(1,n)
    # h_tp1_d <- numeric(n)
    # h_tp1_u <- numeric(n)
    h_tp1_d <- rep(Inf, n)
    h_tp1_u <- rep(Inf, n)

    h_t_d  <- 1-psi_mat[,i]
    h_t_u  <- 1-psi_mat_up[,i]
    #psi <- 1-psi_mat[,i]

    psi_d <- 1-psi_mat[,i]
    psi_u <- 1-psi_mat_up[,i]


    # # track for comparison
    # h_t_d_o <- rep(1,n)
    # h_t_d_mat <- matrix(0, ncol=n, nrow=0)
    # h_t_d_o_mat <-  matrix(0, ncol=n, nrow=0)



    # convergence test
    if(track_conv==TRUE){
      SI_conv_t <- (1-pmin(h_t_d, h_t_u)) %*% h_weights[,1]
      t <- 0
    }

    crit <- TRUE
    #iterative updates for up and downstream
    while(crit == TRUE){

      # replaceability scaling factor
      if(substitution==TRUE){
        p_availability <- (h_t_d * out_str) %*% psup_market
        p_availability <- (p_availability <= 10^-10) * 1 + (p_availability > 10^-10) * p_availability  # still needs to be checked
        p_share <- pmin(1, out_str / p_availability[p_market_cons])
      }else{
        p_share <- 1
      }

      #downstream update of inputs
      pi_t <- 1 - Matrix::crossprod(Lambda_d * p_share, (1 - h_t_d) * psup)


      ## useful for debugging:
      # image(Matrix::crossprod(Lambda_d*p_share, (1 - h_t_d)*psup))
      # for comparison with old approach without essential non essential
      # pi_t_o <- 1 - Matrix::crossprod(Lambda_d * p_share, (1 - h_t_d_o) * rep(1,n))
      # h_tp1_d_o <- pmin(apply(pi_t_o, 1, min),  psi)
      # h_t_d_o   <- h_tp1_d_o



      #cat("\n", i, "\n")
      for(k in 1:n_uni_ess_mat_secs){
        #cat(k, "\n")
        # dim is number of firms in the sector times number of leontief inputs of the sector
        if(sum(uni_ess_mat_sec[,k] == 2) > 0){
          leo_inputs <- apply(pi_t[p_cons_uni_ess_mat==k, uni_ess_mat_sec[,k]==2, drop = FALSE], MARGIN = 1, FUN = min)
        }else{
          leo_inputs <- matrix(1, nrow=sum(p_cons_uni_ess_mat==k), ncol = 1)
        }

        # dim is number of firms in the sector times number of linear inputs of the sector
        if(sum(uni_ess_mat_sec[,k]==1) > 0){
          lin_inputs <- Matrix::rowSums(pi_t[p_cons_uni_ess_mat==k, uni_ess_mat_sec[,k]==1, drop = FALSE]) -  rep(sum(uni_ess_mat_sec[,k]==1), sum(p_cons_uni_ess_mat==k) )+1
        }else{
          lin_inputs <- matrix(1, nrow = sum(p_cons_uni_ess_mat==k), ncol = 1)
        }

        h_tp1_d[p_cons_uni_ess_mat==k] <- pmax(0,
                                               pmin(leo_inputs,
                                                    lin_inputs,
                                                    psi_d[p_cons_uni_ess_mat==k])
                                               )
        #print(h_tp1_d)
        # print(leo_inputs)
        # print(lin_inputs)


      }

      #print(sum(Matrix::which(h_tp1_d==Inf)))

      # for linear only scenario this update is enough
      #      h_tp1_d <- pmin(1, rowSums(pi_t) - dim(pi_t)[2]+1, psi)


      #upstream
      #h_tp1_u <- pmax(0, pmin(psi, 1 - (Lambda_u %*% (1 - h_t_u))))
      h_tp1_u <- pmax(0, pmin(psi_u, 1 - (Lambda_u %*% (1 - h_t_u))))


      if(track_conv==TRUE){
        t <- t + 1
        SI_conv_tm1 <- SI_conv_t
        SI_conv_t <- (1 - pmin(h_tp1_d, h_tp1_u)) %*% h_weights[,1]
        #cat(SI_conv_tm1, SI_conv_t, SI_conv_t/SI_conv_tm1, " ")
      }


      # convergence check
      if(conv_type == 1){
        crit <- max(-h_tp1_d + h_t_d, -h_tp1_u + h_t_u ) > eps   # continue iteration until up and down converged to new stationary state
        #crit <- max(-h_tp1_d + h_t_d ) > eps   # continue iteration until up and down converged to new stationary state
      }else{
        #cat(( (SI_conv_t / SI_conv_tm1) > (1 + eps)) , "\n")
        crit <-  ( (SI_conv_t / SI_conv_tm1) > (1 + eps)) # alternative convergence criterion based on relative increase of systemic risk index
      }


      #h_tm1_d <- h_t_d
      h_t_d   <- h_tp1_d

      # plot(h_t_d)
      # for comparison with old approach
      # h_t_d_mat <- rbind(h_t_d_mat , h_t_d)
      # h_t_d_o_mat <- rbind(h_t_d_o_mat , h_t_d_o)
      #plot(h_t_d_mat , h_t_d_o_mat, log="xy")



      #h_tm1_u <- h_t_u
      h_t_u   <- h_tp1_u


    }

    # save single h vectors 1 - h to be sparse
    # if(track_h == TRUE){ hd_T_mat[,i] <- 1 - h_t_d; hu_T_mat[,i] <- 1 - h_t_u }
    if(track_h == TRUE){ hd_T_mat[,i] <- 1 - round(h_t_d, h_mat_round); hu_T_mat[,i] <- 1 - round(h_t_u, h_mat_round) }


    if(track_conv == TRUE){ ESRI_conv[i,] <- c(SI_conv_tm1, SI_conv_t, t) }

    if(track_sector_impacts == TRUE){

      sec_d_mat_init[i,] <- (as.vector(sec_aggr_weights * psi_mat[,i]) %*% psup_sec_impact) / p_sector_shares
      sec_u_mat_init[i,] <- (as.vector(sec_aggr_weights_up * psi_mat_up[,i]) %*% psup_sec_impact) / p_sector_shares_up
      sec_du_mat_init[i,] <- (as.vector(sec_aggr_weights * psi_mat_up[,i]) %*% psup_sec_impact) / p_sector_shares


      sec_d_mat[i,]  <- (as.vector((1-h_t_d) * sec_aggr_weights) %*% psup_sec_impact) / p_sector_shares -
        sec_d_mat_init[i,]

      # sec_u_mat[i,]  <- (as.vector((1-h_t_u) * sec_aggr_weights) %*% psup_sec_impact) / p_sector_shares -
      #   init_sec_shock
      sec_u_mat[i,]  <- (as.vector((1-h_t_u) * sec_aggr_weights_up) %*% psup_sec_impact) / p_sector_shares_up -
        sec_u_mat_init[i,]
      # psi_mat_up

      # fraction of the sector production (when weight is outstrength) affected from shock propagation
      sec_du_mat[i,] <- (as.vector((1-pmin(h_t_d, h_t_u)) * sec_aggr_weights) %*% psup_sec_impact) / p_sector_shares -
        pmax(sec_d_mat_init[i,], sec_du_mat_init[i,])
    }

    # weight the h vectors
    ESRI[i,] <- as.vector((1 - rbind(pmin(h_t_d, h_t_u), h_t_d, h_t_u)) %*% h_weights)
  }


  outlist <- ESRI

  if(track_h == TRUE){ # note the transpose,
    outlist <- cbind(outlist,
                     Matrix::t(hd_T_mat), # row i indicates damages to all other nodes in scenario i (psi_mat[,i])
                     Matrix::t(hu_T_mat)
    )
  }

  if(track_conv ==TRUE){
    outlist <- cbind(outlist,
                     ESRI_conv
    )
  }

  if(track_sector_impacts == TRUE){
    outlist <- cbind(outlist,
                     sec_d_mat,
                     sec_u_mat,
                     sec_du_mat,
                     sec_d_mat_init,
                     sec_u_mat_init,
                     sec_du_mat_init)
  }

  outlist
}




