#' essential and non essential inputs for 616 nace4 lvl. sectors.
#'
#' The data is based on a survey from IHS markit presented in Figure 12 in
#' Pichler, A., Pangallo, M., del Rio-Chanona, R. M., Lafond, F., & Farmer, J. D. (2021). In and out of lockdown: Propagation of supply and demand shocks in a dynamic input-output model. arXiv preprint arXiv:2102.09608.
#' The 615 nace4 lvl sectors where matched to the 55 sector  WIOD classification used in Pichler et al. 2021.
#' The element kl can take values 0 = negligible, 1 = non-essential and 2 = essential, specifies the essentiality of inputs from sector k for the production of a firm in sector l
#' Note that the NA sector is 9999, i.e. when the sector of a firm is not available
#'
#' @format A matrix double with 616 rows and 616 variables:
#' \describe{
#'   \item{columns}{buying sectors}
#'   \item{rows}{supplying sectors}
#' }
"ess_mat_n4_ihs"


#' NACE ids for the 616 nace4 lvl. sectors matched to three, two and one digit nache levels.
#'
#' The data is based on data available at EUROSTAT RAMON: METADATA DOWNLOAD
#' Statistical Classification of Economic Activities in the European Community, Rev. 2 (2008) (NACE Rev. 2)
#' Note that the NA sector is 9999, i.e. when the sector of a firm is not available
#'
#' @format A dataframe double with 616 rows and 12 variables:
#' \describe{
#'   \item{nace4}{nace4 id of sectors}
#'   \item{nace3}{nace3 id of sectors}
#'   \item{nace2}{nace2 id of sectors}
#'   \item{nace1}{nace1 id of sectors}
#'   \item{nace1_2}{nace1 letter plus nace2 id of sectors}
#'   \item{nace4_num}{nace4 numeric id of sectors}
#'   \item{nace4_desc}{nace4 text descrption}
#'   \item{nace3_desc}{nace3 text descrption}
#'   \item{nace2_desc}{nace2 text descrption}
#'   \item{nace1_desc}{nace1 text descrption}
#'   \item{nace4_desc}{nace4 text descrption}
#'   \item{Reference.to.ISIC.Rev..4}{Reference.to.ISIC.Rev..4}
#'   \item{ihs_markit}{WIOD / ihs markit sector ids for each nace4 id matched}
#' }
"nace_conv_mat"



#' containing the the dummy example from Fig1. in ESRI paper
#'
#' The data is based on Fig1 in Diem, C., Borsos, A., Reisch, T., Kertész, J., & Thurner, S. (2022). Sci. Rep, 12(1), 1-13.
#' the ess_mat_sec (essential matrix for sectors) is for a totally linear cascade, i.e. each input is non-essential
#'
#' @format A list of three
#' \describe{
#'   \item{W}{supply network of 11 times 11}
#'   \item{p}{sectors of firms}
#'   \item{ess_mat_sec}{essential non essential inputs for each sector}
#' }
"example_data"
