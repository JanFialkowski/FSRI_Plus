Rpackage code for simulating production network shock propagation with the Generalized Leontief profuction function. (doi.org/10.1038/s41598-022-11522-z) 

- contains only the R code
- for the c++ code see fastcascade 
