// [[Rcpp::depends(RcppArmadillo)]]
// #define ARMA_64BIT_WORD 1
#include <RcppArmadillo.h>
using namespace Rcpp;




//' Calculate Lambda downstream matrix for mixed production function
//'
//' check for definitions of Lambda_d also the paper: \href{https://arxiv.org/abs/2104.07260}{ESRI}
//'
//' @param W matrix of supply relations, W_ij ... i sends to j the amount W_ij
//' @param n number of firms rows and columns of W
//' @param prodfun_sets vector indicating type of production function for each company, \eqn{prodfun_sets[i]=1} firm is linear, \eqn{prodfun_sets[i]=2} firm is leontief
//' @param serv_supplier_sets vector indicating  for each company it it is providing essential (leontief) goods if \eqn{serv_supplier_sets[i]=2}  or nonessential (linear) goods if \eqn{serv_supplier_sets[i]=1}
//' @param p vector of industry affiliations (product vector), \eqn{p[i]=k} ... company i is of industry k / produces product k
//' @param pi_abs_div n times m matrix, \eqn{pi_abs_div[i,k]} indicates how much firm i sources of industry / product k
//' @param in_str vector of companies' instrengths (colSums(W))
//' @param serv_supp logial / boolean value if essentialness (providing linear or leontief goods) of firms is considered
//' @return  Lambda_d1 matrix of downstream impacts based on firms production function and if providing essential inputs or not
//' @export
// [[Rcpp::export]]
arma::sp_mat Lambda_cpp(arma::sp_mat W,                     // N x N matrix of doubles, containing the inter-firm relations
                        int n,                              // N ... integer, number of firms
                        arma::Col<int> prodfun_sets,        // vec of int (size n); prodfun_set_1[i]=1 if firm is linear, 2 if leontief
                        arma::Col<int> serv_supplier_sets,  // ??
                        arma::uvec p,
                        arma::sp_mat pi_abs_div,          //
                        arma::Col<double> in_str,         // in strength vector
                        bool serv_supp){                  // Use serv_supplier_sets or not

  Rcpp::Rcout << "Starting lambda cpp calculation." << "\n";
  arma::sp_mat Lambda_d1(W);
  arma::sp_mat Lambda_d2(W);


  int n_prod=0;
  for (int i=0; i< prodfun_sets.n_rows; i++){
    if (prodfun_sets[i]==2){ n_prod++;}
  }





  // leontief Lambda_d
  arma::sp_mat::const_iterator start = W.begin();
  arma::sp_mat::const_iterator end   = W.end();

  // Rcpp::Rcout << " Start Lambda_d1 "<<'\n';

  for(arma::sp_mat::const_iterator it = start; it != end; ++it){
    // Rcpp::Rcout <<"it row "<< it.row() << " it col "<< it.col() << " p "<< p(it.row()) << '\n';
    // Rcpp::Rcout <<"I don't think this does: pi= "<< pi_abs_div(it.col(), p(it.row())) << '\n';
    // Rcpp::Rcout <<"I guess this works: L="<< Lambda_d1(it.row(),it.col()) << '\n';
    Lambda_d1(it.row(),it.col()) /= pi_abs_div(it.col(), p(it.row()));   // check this VERY carefully tmrw, is the indexing here the other way round?!?
  }

  // Rcpp::Rcout << " Finish Lambda_d1 "<<'\n';

  // progress report
  //   if((i %% 1000)==0){
  //     timer <- as.character(Sys.time())
  //     cat("iteration", i, timer, "   ")
  //   }
  //

  // # Linear Lambda_d

  // Rcpp::Rcout << " Start Lambda_d2 "<<'\n';

  // arma::sp_mat::const_iterator start = Lambda_d2.begin();
  // arma::sp_mat::const_iterator end   = Lambda_d2.end();
  start = W.begin();
  end   = W.end();


  for(arma::sp_mat::const_iterator it = start; it != end; ++it)
  {
    // Rcpp::Rcout << "hier 3, itrow " << it.row() << " it col " << it.col(); // << "\n";
    Lambda_d2(it.row(),it.col()) /= in_str(it.col());
  }
  // Rcpp::Rcout << " Finish Lambda_d2 "<<'\n';


  for (int i=0; i<Lambda_d1.n_cols; ++i){
    // Rcpp::Rcout << "inside for, col " << i << "prodfun_sets(i)= "<< prodfun_sets(i) << '\n';
    if (prodfun_sets(i)==1){
      Lambda_d1.col(i) = Lambda_d2.col(i);
    }
  }

  if (serv_supp){
    for (int i=0; i<Lambda_d1.n_rows; ++i){
      // Rcpp::Rcout << "inside for, col " << i << "prodfun_sets(i)= "<< prodfun_sets(i) << '\n';
      if (serv_supplier_sets(i)==1){
        Lambda_d1.row(i) = Lambda_d2.row(i);
      }
    }
  }

  //   if(serv_supp ==TRUE){
  //     Lambda_d1[service_supplier_indices,] <- Lambda_d2[service_supplier_indices,]
  //   }
  //
  //   Lambda_d <- Lambda_d1

  return Lambda_d1;
}






// Lambda_d <-  Matrix(0, ncol=n, nrow=n)#sparseMatrix(i=1, j=1, x=0, dims=c(n,n))
//
//   for(i in 1:n){
//     Lambda_d[i,] <- W[i,]/pi_abs_div[,p[i]]
// # progress report
//     if((i %% 1000)==0){
//       timer <- as.character(Sys.time())
//       cat("iteration", i, timer, "   ")
//     }
//   }


//' Calculate Lambda downstream matrix for unmixed production function
//' @param W matrix of supply relations, W_ij ... i sends to j the amount W_ij
//' @param n number of firms rows and columns of W
//' @param p vector of industry affiliations (product vector), \eqn{p[i]=k} ... company i is of industry k / produces product k
//' @param pi_abs_div n times m matrix, \eqn{pi_abs_div[i,k]} indicates how much firm i sources of industry / product k
//' @return  Lambda matrix of downstream impacts based on firms production function either all linear or all Leontief
//' @export
// [[Rcpp::export]]
arma::sp_mat Lambda_cpp_nomixing(arma::sp_mat W,                     // N x N matrix of doubles, containing the inter-firm relations
                        int n,                              // N ... integer, number of firms
                        arma::uvec p,
                        arma::sp_mat pi_abs_div)          // idk check this out, N x M matrix; from .R file: matrix specifying how much inputs are used by company i, row index indicates product type, used to calculate Lambda_d
  {

  Rcpp::Rcout << "Starting lambda cpp calculation, no mixing." << "\n";
  arma::sp_mat Lambda(W);

  arma::sp_mat::const_iterator start = W.begin();
  arma::sp_mat::const_iterator end   = W.end();

  for(arma::sp_mat::const_iterator it = start; it != end; ++it){
    Lambda(it.row(),it.col()) /= pi_abs_div(it.col(), p(it.row()));   // check this VERY carefully tmrw, is the indexing here the other way round?!?
  }
  return Lambda;
  }
