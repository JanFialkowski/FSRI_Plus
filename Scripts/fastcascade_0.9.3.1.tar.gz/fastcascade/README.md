# fastcascade
Rcpp package code that provides faster shock propagation dynamics for the GLcascade package
